<template>
	<view class="root">

	</view>
</template>

<script>
	export default {

		data() {
			return {}
		},
		created() {

		},
		methods: {

		},
	}
</script>

<style scoped lang="scss">

</style>
